package ptithcm.edu.online.service;

import org.springframework.stereotype.Service;
import ptithcm.edu.online.model.MenuItem;
import ptithcm.edu.online.repository.MenuItemRepository;
import ptithcm.edu.online.service.base.BaseServiceImpl;

import java.util.List;

@Service
public class MenuItemService extends BaseServiceImpl<MenuItem, Long> {
    private final MenuItemRepository repository;

    public MenuItemService(MenuItemRepository repository) {
        super(repository);
        this.repository = repository;
    }

    public List<MenuItem> findAvailableByCategory(Long categoryId) {
        return repository.findByCategoryIdAndIsAvailableTrue(categoryId);
    }

    public List<MenuItem> searchByName(String keyword) {
        return repository.findByNameContainingIgnoreCase(keyword);
    }
}