package ptithcm.edu.online.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ptithcm.edu.online.dto.ReviewDto;
import ptithcm.edu.online.mapper.ReviewMapper;
import ptithcm.edu.online.service.ReviewService;

import java.util.List;
import java.util.stream.Collectors;

import ptithcm.edu.online.model.Review;
import ptithcm.edu.online.model.Order;
import ptithcm.edu.online.model.User;
import ptithcm.edu.online.repository.ReviewRepository;
import ptithcm.edu.online.repository.OrderRepository;
import ptithcm.edu.online.repository.UserRepository;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {
    private final ReviewService reviewService;
    private final ReviewMapper reviewMapper;
    private final ReviewRepository reviewRepository;
    private final OrderRepository orderRepository;
    private final UserRepository userRepository;

    public ReviewController(ReviewService reviewService, ReviewMapper reviewMapper, ReviewRepository reviewRepository, OrderRepository orderRepository, UserRepository userRepository) {
        this.reviewService = reviewService;
        this.reviewMapper = reviewMapper;
        this.reviewRepository = reviewRepository;
        this.orderRepository = orderRepository;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<ReviewDto>> getAll() {
        List<ReviewDto> result = reviewService.findAll().stream()
                .map(reviewMapper::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ReviewDto> getById(@PathVariable Long id) {
        return reviewService.findById(id)
                .map(reviewMapper::toDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // --- Added CRUD endpoints ---
    @PostMapping
    public ResponseEntity<ReviewDto> create(@RequestBody ReviewDto dto) {
        if (dto.getOrderId() == null || dto.getUserId() == null || dto.getRating() == null) {
            return ResponseEntity.badRequest().build();
        }
        if (dto.getRating() < 1 || dto.getRating() > 5) {
            return ResponseEntity.badRequest().build();
        }
        // Check existence of order and user
        Order order = orderRepository.findById(dto.getOrderId()).orElse(null);
        User user = userRepository.findById(dto.getUserId()).orElse(null);
        if (order == null || user == null) {
            return ResponseEntity.badRequest().build();
        }
        // Prevent duplicate review for same order-user pair
        if (reviewRepository.findByOrderIdAndUserId(dto.getOrderId(), dto.getUserId()).isPresent()) {
            return ResponseEntity.badRequest().build();
        }
        Review review = new Review();
        review.setOrder(order);
        review.setUser(user);
        review.setRating(dto.getRating());
        review.setComment(dto.getComment());
        Review saved = reviewService.save(review);
        return ResponseEntity.ok(reviewMapper.toDto(saved));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ReviewDto> update(@PathVariable Long id, @RequestBody ReviewDto dto) {
        Review existing = reviewService.findById(id).orElse(null);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        Long newOrderId = existing.getOrder() != null ? existing.getOrder().getId() : null;
        Long newUserId = existing.getUser() != null ? existing.getUser().getId() : null;
        Order newOrder = existing.getOrder();
        User newUser = existing.getUser();
        boolean pairChanged = false;

        if (dto.getOrderId() != null && (newOrderId == null || !dto.getOrderId().equals(newOrderId))) {
            newOrder = orderRepository.findById(dto.getOrderId()).orElse(null);
            if (newOrder == null) {
                return ResponseEntity.badRequest().build();
            }
            newOrderId = dto.getOrderId();
            pairChanged = true;
        }
        if (dto.getUserId() != null && (newUserId == null || !dto.getUserId().equals(newUserId))) {
            newUser = userRepository.findById(dto.getUserId()).orElse(null);
            if (newUser == null) {
                return ResponseEntity.badRequest().build();
            }
            newUserId = dto.getUserId();
            pairChanged = true;
        }
        if (pairChanged) {
            var dup = reviewRepository.findByOrderIdAndUserId(newOrderId, newUserId);
            if (dup.isPresent() && !dup.get().getId().equals(existing.getId())) {
                return ResponseEntity.badRequest().build();
            }
            existing.setOrder(newOrder);
            existing.setUser(newUser);
        }
        if (dto.getRating() != null) {
            if (dto.getRating() < 1 || dto.getRating() > 5) {
                return ResponseEntity.badRequest().build();
            }
            existing.setRating(dto.getRating());
        }
        if (dto.getComment() != null) existing.setComment(dto.getComment());
        Review saved = reviewService.save(existing);
        return ResponseEntity.ok(reviewMapper.toDto(saved));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!reviewService.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        reviewService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}