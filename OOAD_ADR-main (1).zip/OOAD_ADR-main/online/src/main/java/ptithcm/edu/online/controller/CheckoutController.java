package ptithcm.edu.online.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import ptithcm.edu.online.dto.CheckoutRequest;
import ptithcm.edu.online.dto.CheckoutResponse;
import ptithcm.edu.online.dto.OrderItemDto;
import ptithcm.edu.online.mapper.OrderItemMapper;
import ptithcm.edu.online.mapper.OrderMapper;
import ptithcm.edu.online.model.Order;
import ptithcm.edu.online.model.User;
import ptithcm.edu.online.repository.UserRepository;
import ptithcm.edu.online.service.CheckoutService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/checkout")
public class CheckoutController {
    private final CheckoutService checkoutService;
    private final UserRepository userRepository;
    private final OrderMapper orderMapper;
    private final OrderItemMapper orderItemMapper;

    public CheckoutController(  CheckoutService checkoutService,
                                UserRepository userRepository,
                                OrderMapper orderMapper,
                                OrderItemMapper orderItemMapper) {
        this.checkoutService = checkoutService;
        this.userRepository = userRepository;
        this.orderMapper = orderMapper;
        this.orderItemMapper = orderItemMapper;
    }

    @PostMapping
    public ResponseEntity<?> checkout(@RequestBody CheckoutRequest request) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            org.springframework.security.core.userdetails.User principal = (org.springframework.security.core.userdetails.User) auth.getPrincipal();
            User user = userRepository.findByEmail(principal.getUsername()).orElseThrow();

            Order order = checkoutService.checkout(user, request);
            List<OrderItemDto> itemDtos = order.getItems() == null ? List.of() : order.getItems().stream()
                    .map(orderItemMapper::toDto)
                    .collect(Collectors.toList());

            return ResponseEntity.ok(new CheckoutResponse(orderMapper.toDto(order), itemDtos));
        } catch (IllegalArgumentException ex) {
            return ResponseEntity.badRequest().body(ex.getMessage());
        } catch (Exception ex) {
            return ResponseEntity.status(500).body("Checkout thất bại");
        }
    }
}