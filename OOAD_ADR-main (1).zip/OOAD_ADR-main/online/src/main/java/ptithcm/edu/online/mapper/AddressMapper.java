package ptithcm.edu.online.mapper;

import org.springframework.stereotype.Component;
import ptithcm.edu.online.dto.AddressDto;
import ptithcm.edu.online.model.Address;

@Component
public class AddressMapper {
    public AddressDto toDto(Address address) {
        if (address == null) return null;
        AddressDto dto = new AddressDto();
        dto.setId(address.getId());
        dto.setUserId(address.getUser() != null ? address.getUser().getId() : null);
        dto.setFullAddressText(address.getFullAddressText());
        dto.setIsDefault(address.getIsDefault());
        return dto;
    }
}