package ptithcm.edu.online.service.base;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import ptithcm.edu.online.model.base.Identifiable;

import java.util.List;
import java.util.Optional;

public interface BaseService<T extends Identifiable<ID>, ID> {
    Page<T> findAll(Pageable pageable);
    List<T> findAll();
    Optional<T> findById(ID id);
    T save(T entity);
    boolean existsById(ID id);
    void deleteById(ID id);
}