package ptithcm.edu.online.service;

import org.springframework.stereotype.Service;
import ptithcm.edu.online.model.Order;
import ptithcm.edu.online.repository.OrderRepository;
import ptithcm.edu.online.service.base.BaseServiceImpl;

@Service
public class OrderService extends BaseServiceImpl<Order, Long> {
    public OrderService(OrderRepository repository) {
        super(repository);
    }
}