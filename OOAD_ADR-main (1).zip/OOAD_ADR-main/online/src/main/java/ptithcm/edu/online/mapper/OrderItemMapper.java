package ptithcm.edu.online.mapper;

import org.springframework.stereotype.Component;
import ptithcm.edu.online.dto.OrderItemDto;
import ptithcm.edu.online.model.OrderItem;

@Component
public class OrderItemMapper {
    public OrderItemDto toDto(OrderItem item) {
        if (item == null) return null;
        OrderItemDto dto = new OrderItemDto();
        dto.setId(item.getId());
        dto.setOrderId(item.getOrder() != null ? item.getOrder().getId() : null);
        dto.setMenuItemId(item.getMenuItem() != null ? item.getMenuItem().getId() : null);
        dto.setQuantity(item.getQuantity());
        dto.setPrice(item.getPrice());
        dto.setNotes(item.getNotes());
        return dto;
    }
}