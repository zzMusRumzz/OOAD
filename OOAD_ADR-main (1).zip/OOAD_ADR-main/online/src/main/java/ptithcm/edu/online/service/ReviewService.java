package ptithcm.edu.online.service;

import org.springframework.stereotype.Service;
import ptithcm.edu.online.model.Review;
import ptithcm.edu.online.repository.ReviewRepository;
import ptithcm.edu.online.service.base.BaseServiceImpl;

@Service
public class ReviewService extends BaseServiceImpl<Review, Long> {
    public ReviewService(ReviewRepository repository) {
        super(repository);
    }
}