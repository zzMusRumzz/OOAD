package ptithcm.edu.online.mapper;

import org.springframework.stereotype.Component;
import ptithcm.edu.online.dto.MenuItemDto;
import ptithcm.edu.online.model.MenuItem;

@Component
public class MenuItemMapper {
    public MenuItemDto toDto(MenuItem item) {
        if (item == null) return null;
        MenuItemDto dto = new MenuItemDto();
        dto.setId(item.getId());
        dto.setCategoryId(item.getCategory() != null ? item.getCategory().getId() : null);
        dto.setName(item.getName());
        dto.setDescription(item.getDescription());
        dto.setPrice(item.getPrice());
        dto.setImageUrl(item.getImageUrl());
        dto.setIsAvailable(item.getIsAvailable());
        return dto;
    }
}