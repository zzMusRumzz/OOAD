package ptithcm.edu.online.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ptithcm.edu.online.model.Order;
import ptithcm.edu.online.model.enums.OrderStatus;

import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUserIdOrderByCreatedAtDesc(Long userId);
    List<Order> findByOrderStatus(OrderStatus status);
    List<Order> findByUserIdAndOrderStatusIn(Long userId, List<OrderStatus> statuses);
}