package ptithcm.edu.online.model.base;

public interface Identifiable<ID> {
    ID getId();
    void setId(ID id);
}