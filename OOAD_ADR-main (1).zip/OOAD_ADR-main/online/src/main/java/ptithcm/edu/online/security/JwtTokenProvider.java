package ptithcm.edu.online.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Component
public class JwtTokenProvider {
    private final SecretKeySpec secretKey;
    private final long expirationMs;
    private final ObjectMapper objectMapper = new ObjectMapper();

    public JwtTokenProvider(
            @Value("${security.jwt.secret}") String secret,
            @Value("${security.jwt.expirationMs:86400000}") long expirationMs
    ) {
        byte[] secretBytes = secret.getBytes(StandardCharsets.UTF_8);
        if (secretBytes.length < 32) {
            throw new IllegalArgumentException("security.jwt.secret must be at least 32 bytes for HS256");
        }
        this.secretKey = new SecretKeySpec(secretBytes, "HmacSHA256");
        if (expirationMs <= 0) {
            throw new IllegalArgumentException("security.jwt.expirationMs must be positive");
        }
        this.expirationMs = expirationMs;
    }

    public String generateToken(UserDetails userDetails) {
        try {
            Map<String, Object> header = new HashMap<>();
            header.put("alg", "HS256");
            header.put("typ", "JWT");

            String authorities = userDetails.getAuthorities().stream()
                    .map(GrantedAuthority::getAuthority)
                    .collect(Collectors.joining(","));

            Instant now = Instant.now();
            long iat = now.getEpochSecond();
            long exp = now.plusMillis(expirationMs).getEpochSecond();

            Map<String, Object> payload = new HashMap<>();
            payload.put("sub", userDetails.getUsername());
            payload.put("auth", authorities);
            payload.put("iat", iat);
            payload.put("exp", exp);

            String headerJson = objectMapper.writeValueAsString(header);
            String payloadJson = objectMapper.writeValueAsString(payload);

            String headerB64 = base64UrlEncode(headerJson.getBytes(StandardCharsets.UTF_8));
            String payloadB64 = base64UrlEncode(payloadJson.getBytes(StandardCharsets.UTF_8));
            String signingInput = headerB64 + "." + payloadB64;
            String signatureB64 = sign(signingInput);

            return signingInput + "." + signatureB64;
        } catch (Exception e) {
            throw new IllegalStateException("Cannot generate JWT", e);
        }
    }

    public String getUsernameFromToken(String token) {
        try {
            Map<String, Object> claims = parseAndValidateClaims(token);
            Object sub = claims.get("sub");
            return sub != null ? sub.toString() : null;
        } catch (Exception e) {
            return null;
        }
    }

    public boolean validateToken(String token) {
        try {
            parseAndValidateClaims(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private Map<String, Object> parseAndValidateClaims(String token) throws Exception {
        String[] parts = token.split("\\.");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Invalid JWT format");
        }
        String headerB64 = parts[0];
        String payloadB64 = parts[1];
        String signatureB64 = parts[2];

        // Verify signature
        String expectedSig = sign(headerB64 + "." + payloadB64);
        if (!constantTimeEquals(signatureB64, expectedSig)) {
            throw new IllegalArgumentException("Invalid JWT signature");
        }

        // Decode and parse header/payload
        String headerJson = new String(base64UrlDecode(headerB64), StandardCharsets.UTF_8);
        Map<String, Object> header = objectMapper.readValue(headerJson, new TypeReference<Map<String, Object>>() {});
        if (!"HS256".equals(header.get("alg"))) {
            throw new IllegalArgumentException("Unsupported alg");
        }

        String payloadJson = new String(base64UrlDecode(payloadB64), StandardCharsets.UTF_8);
        Map<String, Object> payload = objectMapper.readValue(payloadJson, new TypeReference<Map<String, Object>>() {});

        // Check expiration
        Object expObj = payload.get("exp");
        if (expObj == null) {
            throw new IllegalArgumentException("Missing exp");
        }
        long exp = (expObj instanceof Number) ? ((Number) expObj).longValue() : Long.parseLong(expObj.toString());
        long nowSec = Instant.now().getEpochSecond();
        if (nowSec > exp) {
            throw new IllegalArgumentException("Token expired");
        }

        return payload;
    }

    private String sign(String data) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(secretKey);
        byte[] sig = mac.doFinal(data.getBytes(StandardCharsets.UTF_8));
        return base64UrlEncode(sig);
    }

    private String base64UrlEncode(byte[] data) {
        return Base64.getUrlEncoder().withoutPadding().encodeToString(data);
    }

    private byte[] base64UrlDecode(String data) {
        return Base64.getUrlDecoder().decode(data);
    }

    private boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }
}