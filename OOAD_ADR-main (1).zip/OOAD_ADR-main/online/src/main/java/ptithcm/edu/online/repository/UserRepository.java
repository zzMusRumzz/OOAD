package ptithcm.edu.online.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ptithcm.edu.online.model.User;
import ptithcm.edu.online.model.enums.Role;

import java.util.List;
import java.util.Optional;

public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    Optional<User> findByPhoneNumber(String phoneNumber);
    List<User> findByRole(Role role);
    boolean existsByEmail(String email);
    boolean existsByPhoneNumber(String phoneNumber);
}