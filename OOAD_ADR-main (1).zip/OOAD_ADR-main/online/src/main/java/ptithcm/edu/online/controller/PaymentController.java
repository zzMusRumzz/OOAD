package ptithcm.edu.online.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;
import ptithcm.edu.online.dto.OrderDto;
import ptithcm.edu.online.mapper.OrderMapper;
import ptithcm.edu.online.model.Order;
import ptithcm.edu.online.model.User;
import ptithcm.edu.online.model.enums.OrderStatus;
import ptithcm.edu.online.model.enums.PaymentStatus;
import ptithcm.edu.online.repository.UserRepository;
import ptithcm.edu.online.service.OrderService;

@RestController
@RequestMapping("/api/orders/{orderId}")
public class PaymentController {
    private final OrderService orderService;
    private final UserRepository userRepository;
    private final OrderMapper orderMapper;

    public PaymentController(OrderService orderService, UserRepository userRepository, OrderMapper orderMapper) {
        this.orderService = orderService;
        this.userRepository = userRepository;
        this.orderMapper = orderMapper;
    }

    private User currentUser() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        org.springframework.security.core.userdetails.User principal = (org.springframework.security.core.userdetails.User) auth.getPrincipal();
        return userRepository.findByEmail(principal.getUsername()).orElseThrow();
    }

    private ResponseEntity<?> ensureOwner(Order order, User user) {
        if (order == null) return ResponseEntity.notFound().build();
        if (order.getUser() == null || !order.getUser().getId().equals(user.getId())) {
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body("Chỉ chủ đơn hàng được phép thao tác");
        }
        return null;
    }

    @PostMapping("/payments/initiate")
    public ResponseEntity<?> initiatePayment(@PathVariable Long orderId) {
        User user = currentUser();
        Order order = orderService.findById(orderId).orElse(null);
        ResponseEntity<?> ownerCheck = ensureOwner(order, user);
        if (ownerCheck != null) return ownerCheck;

        if (order.getOrderStatus() == OrderStatus.CANCELLED) {
            return ResponseEntity.badRequest().body("Đơn hàng đã bị huỷ");
        }
        // Nếu đã thanh toán, không thể khởi tạo lại
        if (order.getPaymentStatus() == PaymentStatus.PAID) {
            return ResponseEntity.badRequest().body("Đơn hàng đã thanh toán");
        }
        // Đặt trạng thái thanh toán là PENDING
        order.setPaymentStatus(PaymentStatus.PENDING);
        Order saved = orderService.save(order);
        OrderDto dto = orderMapper.toDto(saved);
        return ResponseEntity.ok(dto);
    }

    @PostMapping("/payments/confirm")
    public ResponseEntity<?> confirmPayment(@PathVariable Long orderId) {
        User user = currentUser();
        Order order = orderService.findById(orderId).orElse(null);
        ResponseEntity<?> ownerCheck = ensureOwner(order, user);
        if (ownerCheck != null) return ownerCheck;

        if (order.getOrderStatus() == OrderStatus.CANCELLED) {
            return ResponseEntity.badRequest().body("Đơn hàng đã bị huỷ");
        }
        if (order.getPaymentStatus() != PaymentStatus.PENDING) {
            return ResponseEntity.badRequest().body("Trạng thái thanh toán không hợp lệ để xác nhận");
        }
        order.setPaymentStatus(PaymentStatus.PAID);
        if (order.getOrderStatus() == OrderStatus.PENDING) {
            order.setOrderStatus(OrderStatus.CONFIRMED);
        }
        Order saved = orderService.save(order);
        OrderDto dto = orderMapper.toDto(saved);
        return ResponseEntity.ok(dto);
    }

    @PostMapping("/cancel")
    public ResponseEntity<?> cancelOrder(@PathVariable Long orderId) {
        User user = currentUser();
        Order order = orderService.findById(orderId).orElse(null);
        ResponseEntity<?> ownerCheck = ensureOwner(order, user);
        if (ownerCheck != null) return ownerCheck;

        if (order.getOrderStatus() == OrderStatus.CANCELLED) {
            return ResponseEntity.badRequest().body("Đơn hàng đã huỷ rồi");
        }
        if (order.getPaymentStatus() == PaymentStatus.PAID) {
            return ResponseEntity.badRequest().body("Đơn hàng đã thanh toán không thể huỷ");
        }
        order.setOrderStatus(OrderStatus.CANCELLED);
        Order saved = orderService.save(order);
        OrderDto dto = orderMapper.toDto(saved);
        return ResponseEntity.ok(dto);
    }
}