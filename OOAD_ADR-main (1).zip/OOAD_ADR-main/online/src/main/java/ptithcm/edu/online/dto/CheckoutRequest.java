package ptithcm.edu.online.dto;

import ptithcm.edu.online.model.enums.PaymentMethod;

import java.util.List;

public class CheckoutRequest {
    private Long addressId;
    private PaymentMethod paymentMethod; // COD or ONLINE_WALLET
    private String notes;
    private List<CheckoutItemRequest> items;

    public Long getAddressId() { return addressId; }
    public void setAddressId(Long addressId) { this.addressId = addressId; }

    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }

    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }

    public List<CheckoutItemRequest> getItems() { return items; }
    public void setItems(List<CheckoutItemRequest> items) { this.items = items; }
}