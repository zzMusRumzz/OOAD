package ptithcm.edu.online.service;

import org.springframework.stereotype.Service;
import ptithcm.edu.online.model.Address;
import ptithcm.edu.online.repository.AddressRepository;
import ptithcm.edu.online.service.base.BaseServiceImpl;

@Service
public class AddressService extends BaseServiceImpl<Address, Long> {
    public AddressService(AddressRepository repository) {
        super(repository);
    }
}