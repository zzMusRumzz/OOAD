package ptithcm.edu.online.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ptithcm.edu.online.dto.MenuItemDto;
import ptithcm.edu.online.mapper.MenuItemMapper;
import ptithcm.edu.online.model.Category;
import ptithcm.edu.online.model.MenuItem;
import ptithcm.edu.online.repository.CategoryRepository;
import ptithcm.edu.online.service.MenuItemService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/menu-items")
public class MenuItemController {
    private final MenuItemService menuItemService;
    private final MenuItemMapper menuItemMapper;
    private final CategoryRepository categoryRepository;

    public MenuItemController(MenuItemService menuItemService, MenuItemMapper menuItemMapper, CategoryRepository categoryRepository) {
        this.menuItemService = menuItemService;
        this.menuItemMapper = menuItemMapper;
        this.categoryRepository = categoryRepository;
    }

    @GetMapping
    public ResponseEntity<List<MenuItemDto>> getAll(
            @RequestParam(value = "categoryId", required = false) Long categoryId,
            @RequestParam(value = "q", required = false) String keyword
    ) {
        List<MenuItem> items;
        if (categoryId != null) {
            items = menuItemService.findAvailableByCategory(categoryId);
        } else if (keyword != null && !keyword.isBlank()) {
            items = menuItemService.searchByName(keyword);
        } else {
            items = menuItemService.findAll();
        }
        List<MenuItemDto> result = items.stream().map(menuItemMapper::toDto).collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MenuItemDto> getById(@PathVariable Long id) {
        return menuItemService.findById(id)
                .map(menuItemMapper::toDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // --- Added CRUD endpoints ---
    @PostMapping
    public ResponseEntity<MenuItemDto> create(@RequestBody MenuItemDto dto) {
        if (dto.getCategoryId() == null || dto.getName() == null || dto.getName().isBlank() || dto.getPrice() == null) {
            return ResponseEntity.badRequest().build();
        }
        Category category = categoryRepository.findById(dto.getCategoryId()).orElse(null);
        if (category == null) {
            return ResponseEntity.badRequest().build();
        }
        MenuItem item = new MenuItem();
        item.setCategory(category);
        item.setName(dto.getName());
        item.setDescription(dto.getDescription());
        item.setPrice(dto.getPrice());
        item.setImageUrl(dto.getImageUrl());
        item.setIsAvailable(dto.getIsAvailable());
        MenuItem saved = menuItemService.save(item);
        return ResponseEntity.ok(menuItemMapper.toDto(saved));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MenuItemDto> update(@PathVariable Long id, @RequestBody MenuItemDto dto) {
        var optional = menuItemService.findById(id);
        if (optional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        MenuItem existing = optional.get();
        if (dto.getCategoryId() != null) {
            Category category = categoryRepository.findById(dto.getCategoryId()).orElse(null);
            if (category == null) {
                return ResponseEntity.badRequest().build();
            }
            existing.setCategory(category);
        }
        if (dto.getName() != null) existing.setName(dto.getName());
        if (dto.getDescription() != null) existing.setDescription(dto.getDescription());
        if (dto.getPrice() != null) existing.setPrice(dto.getPrice());
        if (dto.getImageUrl() != null) existing.setImageUrl(dto.getImageUrl());
        if (dto.getIsAvailable() != null) existing.setIsAvailable(dto.getIsAvailable());
        MenuItem saved = menuItemService.save(existing);
        return ResponseEntity.ok(menuItemMapper.toDto(saved));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!menuItemService.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        menuItemService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}