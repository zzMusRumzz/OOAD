package ptithcm.edu.online.mapper;

import org.springframework.stereotype.Component;
import ptithcm.edu.online.dto.OrderDto;
import ptithcm.edu.online.model.Order;

@Component
public class OrderMapper {
    public OrderDto toDto(Order order) {
        if (order == null) return null;
        OrderDto dto = new OrderDto();
        dto.setId(order.getId());
        dto.setUserId(order.getUser() != null ? order.getUser().getId() : null);
        dto.setAddressId(order.getAddress() != null ? order.getAddress().getId() : null);
        dto.setTotalAmount(order.getTotalAmount());
        dto.setOrderStatus(order.getOrderStatus());
        dto.setPaymentMethod(order.getPaymentMethod());
        dto.setPaymentStatus(order.getPaymentStatus());
        dto.setNotes(order.getNotes());
        dto.setCreatedAt(order.getCreatedAt());
        return dto;
    }
}