package ptithcm.edu.online.model.enums;

public enum Role {
    CUSTOMER,
    ADMIN
}