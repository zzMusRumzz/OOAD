package ptithcm.edu.online.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ptithcm.edu.online.dto.AddressDto;
import ptithcm.edu.online.mapper.AddressMapper;
import ptithcm.edu.online.model.Address;
import ptithcm.edu.online.model.User;
import ptithcm.edu.online.repository.UserRepository;
import ptithcm.edu.online.service.AddressService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {
    private final AddressService addressService;
    private final AddressMapper addressMapper;
    private final UserRepository userRepository;

    public AddressController(AddressService addressService, AddressMapper addressMapper, UserRepository userRepository) {
        this.addressService = addressService;
        this.addressMapper = addressMapper;
        this.userRepository = userRepository;
    }

    @GetMapping
    public ResponseEntity<List<AddressDto>> getAll() {
        List<AddressDto> result = addressService.findAll().stream()
                .map(addressMapper::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<AddressDto> getById(@PathVariable Long id) {
        return addressService.findById(id)
                .map(addressMapper::toDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // --- Added CRUD endpoints ---
    @PostMapping
    public ResponseEntity<AddressDto> create(@RequestBody AddressDto dto) {
        if (dto.getUserId() == null || dto.getFullAddressText() == null || dto.getFullAddressText().isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        User user = userRepository.findById(dto.getUserId()).orElse(null);
        if (user == null) {
            return ResponseEntity.badRequest().build();
        }
        Address address = new Address();
        address.setUser(user);
        address.setFullAddressText(dto.getFullAddressText());
        address.setIsDefault(dto.getIsDefault());
        Address saved = addressService.save(address);
        return ResponseEntity.ok(addressMapper.toDto(saved));
    }

    @PutMapping("/{id}")
    public ResponseEntity<AddressDto> update(@PathVariable Long id, @RequestBody AddressDto dto) {
        var optional = addressService.findById(id);
        if (optional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        Address existing = optional.get();
        if (dto.getUserId() != null) {
            User user = userRepository.findById(dto.getUserId()).orElse(null);
            if (user == null) {
                return ResponseEntity.badRequest().build();
            }
            existing.setUser(user);
        }
        if (dto.getFullAddressText() != null) existing.setFullAddressText(dto.getFullAddressText());
        if (dto.getIsDefault() != null) existing.setIsDefault(dto.getIsDefault());
        Address saved = addressService.save(existing);
        return ResponseEntity.ok(addressMapper.toDto(saved));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!addressService.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        addressService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}