package ptithcm.edu.online.dto;

import java.util.List;

public class CheckoutResponse {
    private OrderDto order;
    private List<OrderItemDto> items;

    public CheckoutResponse() {}
    public CheckoutResponse(OrderDto order, List<OrderItemDto> items) {
        this.order = order;
        this.items = items;
    }

    public OrderDto getOrder() { return order; }
    public void setOrder(OrderDto order) { this.order = order; }

    public List<OrderItemDto> getItems() { return items; }
    public void setItems(List<OrderItemDto> items) { this.items = items; }
}