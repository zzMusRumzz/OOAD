package ptithcm.edu.online.model.enums;

public enum PaymentMethod {
    COD,
    ONLINE_WALLET
}