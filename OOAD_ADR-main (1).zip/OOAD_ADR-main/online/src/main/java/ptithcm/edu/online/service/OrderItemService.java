package ptithcm.edu.online.service;

import org.springframework.stereotype.Service;
import ptithcm.edu.online.model.OrderItem;
import ptithcm.edu.online.repository.OrderItemRepository;
import ptithcm.edu.online.service.base.BaseServiceImpl;

@Service
public class OrderItemService extends BaseServiceImpl<OrderItem, Long> {
    public OrderItemService(OrderItemRepository repository) {
        super(repository);
    }
}