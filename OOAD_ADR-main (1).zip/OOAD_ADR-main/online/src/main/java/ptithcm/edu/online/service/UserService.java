package ptithcm.edu.online.service;

import org.springframework.stereotype.Service;
import ptithcm.edu.online.model.User;
import ptithcm.edu.online.repository.UserRepository;
import ptithcm.edu.online.service.base.BaseServiceImpl;

@Service
public class UserService extends BaseServiceImpl<User, Long> {
    public UserService(UserRepository repository) {
        super(repository);
    }
}