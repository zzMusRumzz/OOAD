package ptithcm.edu.online.mapper;

import org.springframework.stereotype.Component;
import ptithcm.edu.online.dto.ReviewDto;
import ptithcm.edu.online.model.Review;

@Component
public class ReviewMapper {
    public ReviewDto toDto(Review review) {
        if (review == null) return null;
        ReviewDto dto = new ReviewDto();
        dto.setId(review.getId());
        dto.setOrderId(review.getOrder() != null ? review.getOrder().getId() : null);
        dto.setUserId(review.getUser() != null ? review.getUser().getId() : null);
        dto.setRating(review.getRating());
        dto.setComment(review.getComment());
        dto.setCreatedAt(review.getCreatedAt());
        return dto;
    }
}