package ptithcm.edu.online.model.enums;

public enum PaymentStatus {
    PENDING,
    PAID
}