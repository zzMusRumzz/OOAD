package ptithcm.edu.online.service;

import org.springframework.stereotype.Service;
import ptithcm.edu.online.model.Category;
import ptithcm.edu.online.repository.CategoryRepository;
import ptithcm.edu.online.service.base.BaseServiceImpl;

@Service
public class CategoryService extends BaseServiceImpl<Category, Long> {
    public CategoryService(CategoryRepository repository) {
        super(repository);
    }
}