package ptithcm.edu.online.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import ptithcm.edu.online.dto.OrderItemDto;
import ptithcm.edu.online.mapper.OrderItemMapper;
import ptithcm.edu.online.service.OrderItemService;

import java.util.List;
import java.util.stream.Collectors;

import ptithcm.edu.online.model.OrderItem;
import ptithcm.edu.online.model.Order;
import ptithcm.edu.online.model.MenuItem;
import ptithcm.edu.online.repository.OrderRepository;
import ptithcm.edu.online.repository.MenuItemRepository;

@RestController
@RequestMapping("/api/order-items")
public class OrderItemController {
    private final OrderItemService orderItemService;
    private final OrderItemMapper orderItemMapper;
    private final OrderRepository orderRepository;
    private final MenuItemRepository menuItemRepository;

    public OrderItemController(OrderItemService orderItemService, OrderItemMapper orderItemMapper, OrderRepository orderRepository, MenuItemRepository menuItemRepository) {
        this.orderItemService = orderItemService;
        this.orderItemMapper = orderItemMapper;
        this.orderRepository = orderRepository;
        this.menuItemRepository = menuItemRepository;
    }

    @GetMapping
    public ResponseEntity<List<OrderItemDto>> getAll() {
        List<OrderItemDto> result = orderItemService.findAll().stream()
                .map(orderItemMapper::toDto)
                .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

    @GetMapping("/{id}")
    public ResponseEntity<OrderItemDto> getById(@PathVariable Long id) {
        return orderItemService.findById(id)
                .map(orderItemMapper::toDto)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<OrderItemDto> create(@RequestBody OrderItemDto dto) {
        if (dto.getOrderId() == null || dto.getMenuItemId() == null || dto.getQuantity() == null || dto.getQuantity() <= 0 || dto.getPrice() == null) {
            return ResponseEntity.badRequest().build();
        }
        Order order = orderRepository.findById(dto.getOrderId()).orElse(null);
        MenuItem menuItem = menuItemRepository.findById(dto.getMenuItemId()).orElse(null);
        if (order == null || menuItem == null) {
            return ResponseEntity.badRequest().build();
        }
        OrderItem entity = new OrderItem();
        entity.setOrder(order);
        entity.setMenuItem(menuItem);
        entity.setQuantity(dto.getQuantity());
        entity.setPrice(dto.getPrice());
        entity.setNotes(dto.getNotes());
        OrderItem saved = orderItemService.save(entity);
        return ResponseEntity.ok(orderItemMapper.toDto(saved));
    }

    @PutMapping("/{id}")
    public ResponseEntity<OrderItemDto> update(@PathVariable Long id, @RequestBody OrderItemDto dto) {
        OrderItem existing = orderItemService.findById(id).orElse(null);
        if (existing == null) {
            return ResponseEntity.notFound().build();
        }
        if (dto.getOrderId() != null) {
            Order order = orderRepository.findById(dto.getOrderId()).orElse(null);
            if (order == null) {
                return ResponseEntity.badRequest().build();
            }
            existing.setOrder(order);
        }
        if (dto.getMenuItemId() != null) {
            MenuItem menuItem = menuItemRepository.findById(dto.getMenuItemId()).orElse(null);
            if (menuItem == null) {
                return ResponseEntity.badRequest().build();
            }
            existing.setMenuItem(menuItem);
        }
        if (dto.getQuantity() != null) {
            if (dto.getQuantity() <= 0) {
                return ResponseEntity.badRequest().build();
            }
            existing.setQuantity(dto.getQuantity());
        }
        if (dto.getPrice() != null) {
            existing.setPrice(dto.getPrice());
        }
        if (dto.getNotes() != null) {
            existing.setNotes(dto.getNotes());
        }
        OrderItem saved = orderItemService.save(existing);
        return ResponseEntity.ok(orderItemMapper.toDto(saved));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (orderItemService.findById(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        orderItemService.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}