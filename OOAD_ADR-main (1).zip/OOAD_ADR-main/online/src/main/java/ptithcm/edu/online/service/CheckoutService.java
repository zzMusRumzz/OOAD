package ptithcm.edu.online.service;

import jakarta.transaction.Transactional;
import org.springframework.stereotype.Service;
import ptithcm.edu.online.dto.CheckoutItemRequest;
import ptithcm.edu.online.dto.CheckoutRequest;
import ptithcm.edu.online.model.Address;
import ptithcm.edu.online.model.MenuItem;
import ptithcm.edu.online.model.Order;
import ptithcm.edu.online.model.OrderItem;
import ptithcm.edu.online.model.User;
import ptithcm.edu.online.model.enums.OrderStatus;
import ptithcm.edu.online.model.enums.PaymentMethod;
import ptithcm.edu.online.model.enums.PaymentStatus;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Service
public class CheckoutService {
    private final OrderService orderService;
    private final AddressService addressService;
    private final MenuItemService menuItemService;

    public CheckoutService(OrderService orderService, AddressService addressService, MenuItemService menuItemService) {
        this.orderService = orderService;
        this.addressService = addressService;
        this.menuItemService = menuItemService;
    }

    @Transactional
    public Order checkout(User user, CheckoutRequest request) {
        if (user == null) throw new IllegalArgumentException("User is required");
        if (request == null || request.getAddressId() == null || request.getItems() == null || request.getItems().isEmpty()) {
            throw new IllegalArgumentException("Thiếu thông tin checkout: addressId và items");
        }
        PaymentMethod method = request.getPaymentMethod() != null ? request.getPaymentMethod() : PaymentMethod.COD;

        Address address = addressService.findById(request.getAddressId()).orElseThrow(() -> new IllegalArgumentException("Địa chỉ không tồn tại"));
        if (address.getUser() == null || !address.getUser().getId().equals(user.getId())) {
            throw new IllegalArgumentException("Địa chỉ không thuộc về người dùng hiện tại");
        }

        BigDecimal total = BigDecimal.ZERO;
        List<OrderItem> items = new ArrayList<>();
        for (CheckoutItemRequest itemReq : request.getItems()) {
            if (itemReq.getMenuItemId() == null || itemReq.getQuantity() == null || itemReq.getQuantity() <= 0) {
                throw new IllegalArgumentException("Mục hàng không hợp lệ: menuItemId và quantity > 0");
            }
            MenuItem menuItem = menuItemService.findById(itemReq.getMenuItemId())
                    .orElseThrow(() -> new IllegalArgumentException("Món ăn không tồn tại: id=" + itemReq.getMenuItemId()));
            if (menuItem.getIsAvailable() != null && !menuItem.getIsAvailable()) {
                throw new IllegalArgumentException("Món ăn hiện không khả dụng: " + menuItem.getName());
            }
            BigDecimal price = menuItem.getPrice();
            BigDecimal lineTotal = price.multiply(BigDecimal.valueOf(itemReq.getQuantity()));
            total = total.add(lineTotal);

            OrderItem orderItem = new OrderItem();
            orderItem.setMenuItem(menuItem);
            orderItem.setQuantity(itemReq.getQuantity());
            orderItem.setPrice(price);
            orderItem.setNotes(itemReq.getNotes());
            items.add(orderItem);
        }

        Order order = new Order();
        order.setUser(user);
        order.setAddress(address);
        order.setTotalAmount(total);
        order.setOrderStatus(OrderStatus.PENDING);
        order.setPaymentMethod(method);
        order.setPaymentStatus(PaymentStatus.PENDING);
        order.setNotes(request.getNotes());

        // Link items to the order
        for (OrderItem oi : items) {
            oi.setOrder(order);
        }
        order.setItems(items);

        return orderService.save(order);
    }
}