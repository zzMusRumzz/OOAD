package com.fooddelivery.app.activities;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fooddelivery.app.R;
import com.fooddelivery.app.api.ApiClient;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RegisterActivity extends AppCompatActivity {

    private EditText fullNameEditText;
    private EditText emailEditText;
    private EditText phoneEditText;
    private EditText passwordEditText;
    private Button registerButton;
    private TextView loginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        initViews();
        setupClickListeners();
    }

    private void initViews() {
        fullNameEditText = findViewById(R.id.fullNameEditText);
        emailEditText = findViewById(R.id.registerEmailEditText);
        phoneEditText = findViewById(R.id.phoneEditText);
        passwordEditText = findViewById(R.id.registerPasswordEditText);
        registerButton = findViewById(R.id.registerSubmitButton);
        loginLink = findViewById(R.id.loginLink);
    }

    private void setupClickListeners() {
        registerButton.setOnClickListener(v -> performRegister());
        loginLink.setOnClickListener(v -> finish());
    }

    private void performRegister() {
        String fullName = fullNameEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String phone = phoneEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (!validateInputs(fullName, email, phone, password)) {
            return;
        }

        registerButton.setEnabled(false);
        registerButton.setText(R.string.register_loading);

        Map<String, String> request = new HashMap<>();
        request.put("fullName", fullName);
        request.put("email", email);
        request.put("phoneNumber", phone);
        request.put("password", password);

        Call<Map<String, Object>> call = ApiClient.getApiService().register(request);
        call.enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                registerButton.setEnabled(true);
                registerButton.setText(R.string.register);

                if (response.isSuccessful()) {
                    Toast.makeText(RegisterActivity.this, R.string.register_success, Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(RegisterActivity.this, R.string.register_error_exists, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                registerButton.setEnabled(true);
                registerButton.setText(R.string.register);
                Toast.makeText(RegisterActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validateInputs(String fullName, String email, String phone, String password) {
        if (TextUtils.isEmpty(fullName)) {
            fullNameEditText.setError(getString(R.string.error_fullname_required));
            return false;
        }

        if (TextUtils.isEmpty(email)) {
            emailEditText.setError(getString(R.string.error_email_required));
            return false;
        }

        if (TextUtils.isEmpty(phone)) {
            phoneEditText.setError(getString(R.string.error_phone_required));
            return false;
        }

        if (TextUtils.isEmpty(password)) {
            passwordEditText.setError(getString(R.string.error_password_required));
            return false;
        }

        if (password.length() < 6) {
            passwordEditText.setError(getString(R.string.error_password_length));
            return false;
        }

        return true;
    }
}
