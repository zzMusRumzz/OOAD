package com.fooddelivery.app.models.enums;

public enum PaymentMethod {
    COD,
    ONLINE_WALLET
}
