package com.fooddelivery.app.activities;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.*;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.fooddelivery.app.R;
import com.fooddelivery.app.api.ApiClient;
import com.fooddelivery.app.models.*;
import com.fooddelivery.app.models.enums.PaymentMethod;
import com.fooddelivery.app.utils.CartManager;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CheckoutActivity extends AppCompatActivity {

    private EditText addressInput;
    private Spinner paymentMethodSpinner;
    private EditText notesInput;
    private TextView totalText;
    private ProgressBar progressBar;
    private Button placeOrderButton;
    private SharedPreferences sharedPreferences;
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_checkout);

        sharedPreferences = getSharedPreferences("FoodDelivery", MODE_PRIVATE);

    addressInput = findViewById(R.id.checkoutAddressIdInput);
        paymentMethodSpinner = findViewById(R.id.checkoutPaymentMethodSpinner);
        notesInput = findViewById(R.id.checkoutNotesInput);
        totalText = findViewById(R.id.checkoutTotalText);
        progressBar = findViewById(R.id.checkoutProgressBar);
        placeOrderButton = findViewById(R.id.checkoutPlaceOrderButton);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,
                new String[]{getString(R.string.payment_method_cod), getString(R.string.payment_method_online_wallet)});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        paymentMethodSpinner.setAdapter(adapter);

        double total = CartManager.calculateTotal(CartManager.getCartItems(this));
        totalText.setText(getString(R.string.checkout_total_format, currencyFormat.format(total)));

        placeOrderButton.setOnClickListener(v -> performCheckout());
    }

    private void performCheckout() {
        String token = sharedPreferences.getString("token", null);
        if (token == null) {
            Toast.makeText(this, R.string.orders_login_required, Toast.LENGTH_SHORT).show();
            return;
        }
        String addressRaw = addressInput.getText().toString().trim();
        if (TextUtils.isEmpty(addressRaw)) {
            addressInput.setError(getString(R.string.checkout_address_required));
            return;
        }
        Long addressId = null;
        // Nếu người dùng nhập số -> coi như ID có sẵn, nếu nhập chữ -> cần tạo địa chỉ mới
        try {
            addressId = Long.parseLong(addressRaw);
        } catch (NumberFormatException ignore) {
            // sẽ tạo địa chỉ mới khi checkout
        }
        PaymentMethod method = paymentMethodSpinner.getSelectedItemPosition() == 1 ? PaymentMethod.ONLINE_WALLET : PaymentMethod.COD;
        String notes = notesInput.getText().toString().trim();

        List<CartItem> cartItems = CartManager.getCartItems(this);
        if (cartItems.isEmpty()) {
            Toast.makeText(this, R.string.cart_empty, Toast.LENGTH_SHORT).show();
            return;
        }
        List<CheckoutItemRequest> itemRequests = new ArrayList<>();
        for (CartItem ci : cartItems) {
            itemRequests.add(new CheckoutItemRequest(ci.getItemId(), ci.getQuantity(), ci.getNotes()));
        }
        // Nếu cần tạo địa chỉ mới ta sẽ thực hiện request phụ rồi dùng id trả về
        if (addressId == null) {
            createAddressThenCheckout(addressRaw, method, notes, itemRequests, token);
            return;
        }
        CheckoutRequest request = new CheckoutRequest(addressId, method, notes, itemRequests);

        progressBar.setVisibility(View.VISIBLE);
        placeOrderButton.setEnabled(false);
        Call<CheckoutResponse> call = ApiClient.getApiService().checkout("Bearer " + token, request);
        call.enqueue(new Callback<CheckoutResponse>() {
            @Override
            public void onResponse(Call<CheckoutResponse> call, Response<CheckoutResponse> response) {
                progressBar.setVisibility(View.GONE);
                placeOrderButton.setEnabled(true);
                if (response.isSuccessful() && response.body() != null) {
                    Order order = response.body().getOrder();
                    if (method == PaymentMethod.ONLINE_WALLET) {
                        initiatePayment(order.getId(), token);
                    } else {
                        Toast.makeText(CheckoutActivity.this, R.string.checkout_success, Toast.LENGTH_SHORT).show();
                        CartManager.clearCart(CheckoutActivity.this);
                        finish();
                    }
                } else {
                    Toast.makeText(CheckoutActivity.this, R.string.checkout_error, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CheckoutResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                placeOrderButton.setEnabled(true);
                Toast.makeText(CheckoutActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void createAddressThenCheckout(String addressText, PaymentMethod method, String notes, List<CheckoutItemRequest> itemRequests, String token) {
        progressBar.setVisibility(View.VISIBLE);
        placeOrderButton.setEnabled(false);
        // Tạo body đơn giản
        java.util.Map<String, Object> body = new java.util.HashMap<>();
        body.put("fullAddressText", addressText);
        body.put("isDefault", false);

        // Gọi tạm endpoint POST /api/addresses (yêu cầu backend cho phép userId nội suy từ token; nếu không cần chỉnh backend)
        // Ở đây tạm giả định backend chấp nhận thiếu userId và tự set dựa vào token. Nếu không, cần sửa backend.
        retrofit2.Call<java.util.Map<String, Object>> call = ApiClient.getApiService().createAddress("Bearer " + token, body);
        call.enqueue(new retrofit2.Callback<java.util.Map<String, Object>>() {
            @Override
            public void onResponse(retrofit2.Call<java.util.Map<String, Object>> call, retrofit2.Response<java.util.Map<String, Object>> response) {
                if (response.isSuccessful() && response.body() != null && response.body().get("id") != null) {
                    Number idNum = (Number) response.body().get("id");
                    Long newAddressId = idNum.longValue();
                    CheckoutRequest req = new CheckoutRequest(newAddressId, method, notes, itemRequests);
                    proceedCheckout(req, token, method);
                } else {
                    progressBar.setVisibility(View.GONE);
                    placeOrderButton.setEnabled(true);
                    Toast.makeText(CheckoutActivity.this, R.string.address_create_failed, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(retrofit2.Call<java.util.Map<String, Object>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                placeOrderButton.setEnabled(true);
                Toast.makeText(CheckoutActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void proceedCheckout(CheckoutRequest request, String token, PaymentMethod method) {
        Call<CheckoutResponse> call = ApiClient.getApiService().checkout("Bearer " + token, request);
        call.enqueue(new Callback<CheckoutResponse>() {
            @Override
            public void onResponse(Call<CheckoutResponse> call, Response<CheckoutResponse> response) {
                progressBar.setVisibility(View.GONE);
                placeOrderButton.setEnabled(true);
                if (response.isSuccessful() && response.body() != null) {
                    Order order = response.body().getOrder();
                    if (method == PaymentMethod.ONLINE_WALLET) {
                        initiatePayment(order.getId(), token);
                    } else {
                        Toast.makeText(CheckoutActivity.this, R.string.checkout_success, Toast.LENGTH_SHORT).show();
                        CartManager.clearCart(CheckoutActivity.this);
                        finish();
                    }
                } else {
                    Toast.makeText(CheckoutActivity.this, R.string.checkout_error, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<CheckoutResponse> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                placeOrderButton.setEnabled(true);
                Toast.makeText(CheckoutActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void initiatePayment(long orderId, String token) {
        progressBar.setVisibility(View.VISIBLE);
        Call<Order> initCall = ApiClient.getApiService().initiatePayment("Bearer " + token, orderId);
        initCall.enqueue(new Callback<Order>() {
            @Override
            public void onResponse(Call<Order> call, Response<Order> response) {
                if (response.isSuccessful() && response.body() != null) {
                    confirmPayment(orderId, token); // auto-confirm for demo
                } else {
                    progressBar.setVisibility(View.GONE);
                    Toast.makeText(CheckoutActivity.this, R.string.payment_initiate_failed, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Order> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(CheckoutActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void confirmPayment(long orderId, String token) {
        Call<Order> confirmCall = ApiClient.getApiService().confirmPayment("Bearer " + token, orderId);
        confirmCall.enqueue(new Callback<Order>() {
            @Override
            public void onResponse(Call<Order> call, Response<Order> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null) {
                    Toast.makeText(CheckoutActivity.this, R.string.payment_success, Toast.LENGTH_SHORT).show();
                    CartManager.clearCart(CheckoutActivity.this);
                    finish();
                } else {
                    Toast.makeText(CheckoutActivity.this, R.string.payment_confirm_failed, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Order> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(CheckoutActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
