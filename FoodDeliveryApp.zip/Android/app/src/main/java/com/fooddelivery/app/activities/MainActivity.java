package com.fooddelivery.app.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fooddelivery.app.R;
import com.fooddelivery.app.adapters.CategoryAdapter;
import com.fooddelivery.app.api.ApiClient;
import com.fooddelivery.app.models.Category;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    
    private RecyclerView categoriesRecyclerView;
    private CategoryAdapter categoryAdapter;
    private Button loginButton, cartButton, ordersButton, adminButton;
    private TextView welcomeText;
    private SharedPreferences sharedPreferences;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        sharedPreferences = getSharedPreferences("FoodDelivery", MODE_PRIVATE);
        
        initViews();
        setupClickListeners();
        loadCategories();
        updateUI();
    }
    
    @Override
    protected void onResume() {
        super.onResume();
        updateUI();
    }
    
    private void initViews() {
        categoriesRecyclerView = findViewById(R.id.categoriesRecyclerView);
        loginButton = findViewById(R.id.loginButton);
        cartButton = findViewById(R.id.cartButton);
        ordersButton = findViewById(R.id.ordersButton);
        adminButton = findViewById(R.id.adminButton);
        welcomeText = findViewById(R.id.welcomeText);
        
        // Setup RecyclerView
        categoriesRecyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        categoryAdapter = new CategoryAdapter(new ArrayList<>(), category -> {
            Intent intent = new Intent(MainActivity.this, MenuActivity.class);
            intent.putExtra("categoryId", category.getId());
            intent.putExtra("categoryName", category.getName());
            startActivity(intent);
        });
        categoriesRecyclerView.setAdapter(categoryAdapter);
    }
    
    private void setupClickListeners() {
        loginButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });
        
        cartButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, CartActivity.class);
            startActivity(intent);
        });
        
        ordersButton.setOnClickListener(v -> {
            if (isLoggedIn()) {
                Intent intent = new Intent(MainActivity.this, OrdersActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        
        adminButton.setOnClickListener(v -> {
            if (isLoggedIn() && isAdmin()) {
                Intent intent = new Intent(MainActivity.this, AdminActivity.class);
                startActivity(intent);
            } else {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
    
    private void loadCategories() {
        Call<List<Category>> call = ApiClient.getApiService().getCategories();
        call.enqueue(new Callback<List<Category>>() {
            @Override
            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    categoryAdapter.updateCategories(response.body());
                }
            }

            @Override
            public void onFailure(Call<List<Category>> call, Throwable t) {
                // Handle error - show toast or error message
            }
        });
    }
    
    private void updateUI() {
        if (isLoggedIn()) {
            String fullName = sharedPreferences.getString("fullName", "User");
            welcomeText.setText("Xin chào, " + fullName);
            loginButton.setText("Đăng xuất");
            loginButton.setOnClickListener(v -> logout());
            
            ordersButton.setVisibility(View.VISIBLE);
            
            if (isAdmin()) {
                adminButton.setVisibility(View.VISIBLE);
            } else {
                adminButton.setVisibility(View.GONE);
            }
        } else {
            welcomeText.setText("Chào mừng đến với Food Delivery");
            loginButton.setText("Đăng nhập");
            loginButton.setOnClickListener(v -> {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            });
            
            ordersButton.setVisibility(View.GONE);
            adminButton.setVisibility(View.GONE);
        }
    }
    
    private boolean isLoggedIn() {
        return sharedPreferences.getString("token", null) != null;
    }
    
    private boolean isAdmin() {
        String role = sharedPreferences.getString("role", "");
        return role != null && role.equalsIgnoreCase("admin");
    }
    
    private void logout() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        updateUI();
    }
}