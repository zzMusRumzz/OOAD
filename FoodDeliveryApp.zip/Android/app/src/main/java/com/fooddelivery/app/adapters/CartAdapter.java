package com.fooddelivery.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.fooddelivery.app.R;
import com.fooddelivery.app.models.CartItem;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    public interface CartItemListener {
        void onQuantityChanged(CartItem item, int newQuantity);
        void onItemRemoved(CartItem item);
    }

    private final List<CartItem> cartItems = new ArrayList<>();
    private final CartItemListener listener;
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

    public CartAdapter(CartItemListener listener) {
        this.listener = listener;
    }

    public void updateItems(List<CartItem> items) {
        cartItems.clear();
        if (items != null) {
            cartItems.addAll(items);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        holder.bind(cartItems.get(position));
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    class CartViewHolder extends RecyclerView.ViewHolder {
        private final ImageView itemImage;
        private final TextView itemName;
        private final TextView itemPrice;
        private final TextView itemQuantity;
        private final TextView itemTotal;
        private final ImageButton minusButton;
        private final ImageButton plusButton;
        private final ImageButton deleteButton;

        CartViewHolder(@NonNull View itemView) {
            super(itemView);
            itemImage = itemView.findViewById(R.id.cartItemImage);
            itemName = itemView.findViewById(R.id.cartItemName);
            itemPrice = itemView.findViewById(R.id.cartItemPrice);
            itemQuantity = itemView.findViewById(R.id.cartItemQuantity);
            itemTotal = itemView.findViewById(R.id.cartItemTotal);
            minusButton = itemView.findViewById(R.id.quantityMinusButton);
            plusButton = itemView.findViewById(R.id.quantityPlusButton);
            deleteButton = itemView.findViewById(R.id.deleteCartItemButton);
        }

        void bind(CartItem item) {
            itemName.setText(item.getItemName());
            itemPrice.setText(currencyFormat.format(item.getPrice()));
            itemQuantity.setText(String.valueOf(item.getQuantity()));
            itemTotal.setText(currencyFormat.format(item.getTotalPrice()));

            Glide.with(itemImage.getContext())
                    .load(item.getImageUrl())
                    .placeholder(R.drawable.ic_food_placeholder)
                    .error(R.drawable.ic_food_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(itemImage);

            minusButton.setOnClickListener(v -> {
                int newQuantity = Math.max(1, item.getQuantity() - 1);
                if (listener != null) {
                    listener.onQuantityChanged(item, newQuantity);
                }
            });

            plusButton.setOnClickListener(v -> {
                int newQuantity = item.getQuantity() + 1;
                if (listener != null) {
                    listener.onQuantityChanged(item, newQuantity);
                }
            });

            deleteButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onItemRemoved(item);
                }
            });
        }
    }
}
