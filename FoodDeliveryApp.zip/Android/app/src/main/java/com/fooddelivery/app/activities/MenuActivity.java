package com.fooddelivery.app.activities;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fooddelivery.app.R;
import com.fooddelivery.app.adapters.MenuAdapter;
import com.fooddelivery.app.api.ApiClient;
import com.fooddelivery.app.models.MenuItem;
import com.fooddelivery.app.utils.CartManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MenuActivity extends AppCompatActivity implements MenuAdapter.OnMenuItemListener {

    public static final String EXTRA_CATEGORY_ID = "categoryId";
    public static final String EXTRA_CATEGORY_NAME = "categoryName";

    private int categoryId;
    private static final String TAG = "MenuActivity";
    private MenuAdapter menuAdapter;
    private ProgressBar progressBar;
    private View emptyStateView;
    private TextView titleText;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        categoryId = getIntent().getIntExtra(EXTRA_CATEGORY_ID, -1);
        String categoryName = getIntent().getStringExtra(EXTRA_CATEGORY_NAME);

        titleText = findViewById(R.id.menuTitle);
        progressBar = findViewById(R.id.menuProgressBar);
        emptyStateView = findViewById(R.id.menuEmptyState);
        RecyclerView menuRecyclerView = findViewById(R.id.menuRecyclerView);
        FloatingActionButton openCartFab = findViewById(R.id.openCartFab);

        titleText.setText(categoryName != null ? categoryName : getString(R.string.menu_default_title));

        menuAdapter = new MenuAdapter(this);
        menuRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        menuRecyclerView.setAdapter(menuAdapter);

        openCartFab.setOnClickListener(v -> startActivity(new Intent(MenuActivity.this, CartActivity.class)));

        loadMenuItems();
    }

    private void loadMenuItems() {
        if (categoryId == -1) {
            Toast.makeText(this, R.string.menu_missing_category, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        progressBar.setVisibility(View.VISIBLE);
        emptyStateView.setVisibility(View.GONE);

        Call<List<MenuItem>> call = ApiClient.getApiService().getMenuItemsByCategory(categoryId);
        call.enqueue(new Callback<List<MenuItem>>() {
            @Override
            public void onResponse(Call<List<MenuItem>> call, Response<List<MenuItem>> response) {
                progressBar.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    menuAdapter.updateMenuItems(response.body());
                    emptyStateView.setVisibility(View.GONE);
                } else {
                    Log.w(TAG, "Empty or unsuccessful menu items response. code=" + response.code());
                    menuAdapter.updateMenuItems(null);
                    emptyStateView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<List<MenuItem>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                emptyStateView.setVisibility(View.VISIBLE);
                Log.e(TAG, "Failed to load menu items", t);
                Toast.makeText(MenuActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onAddToCart(MenuItem menuItem) {
        CartManager.addToCart(this, menuItem);
        Toast.makeText(this, getString(R.string.menu_item_added_to_cart, menuItem.getName()), Toast.LENGTH_SHORT).show();
    }
}
