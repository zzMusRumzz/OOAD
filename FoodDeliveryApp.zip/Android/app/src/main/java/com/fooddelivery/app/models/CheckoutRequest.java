package com.fooddelivery.app.models;

import com.fooddelivery.app.models.enums.PaymentMethod;
import java.util.List;

public class CheckoutRequest {
    private long addressId;
    private PaymentMethod paymentMethod;
    private String notes;
    private List<CheckoutItemRequest> items;

    public CheckoutRequest(long addressId, PaymentMethod paymentMethod, String notes, List<CheckoutItemRequest> items) {
        this.addressId = addressId;
        this.paymentMethod = paymentMethod;
        this.notes = notes;
        this.items = items;
    }

    public long getAddressId() { return addressId; }
    public void setAddressId(long addressId) { this.addressId = addressId; }
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) { this.paymentMethod = paymentMethod; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
    public List<CheckoutItemRequest> getItems() { return items; }
    public void setItems(List<CheckoutItemRequest> items) { this.items = items; }
}
