package com.fooddelivery.app.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.fooddelivery.app.models.CartItem;
import com.fooddelivery.app.models.MenuItem;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class CartManager {

    private static final String PREF_NAME = "FoodDelivery";
    private static final String KEY_CART_ITEMS = "cart_items";
    private static final Gson gson = new Gson();
    private static final Type CART_TYPE = new TypeToken<List<CartItem>>() {}.getType();

    private CartManager() {
        // Utility class
    }

    private static SharedPreferences getPreferences(Context context) {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static List<CartItem> getCartItems(Context context) {
        String json = getPreferences(context).getString(KEY_CART_ITEMS, null);
        if (json == null || json.isEmpty()) {
            return new ArrayList<>();
        }
        List<CartItem> items = gson.fromJson(json, CART_TYPE);
        return items != null ? items : new ArrayList<>();
    }

    public static void saveCart(Context context, List<CartItem> cartItems) {
        String json = gson.toJson(cartItems);
        getPreferences(context).edit().putString(KEY_CART_ITEMS, json).apply();
    }

    public static void addToCart(Context context, MenuItem menuItem) {
        List<CartItem> cartItems = getCartItems(context);
        CartItem existing = null;
        for (CartItem item : cartItems) {
            if (item.getItemId() == menuItem.getId()) {
                existing = item;
                break;
            }
        }
        if (existing == null) {
            CartItem newItem = new CartItem(menuItem.getId(), menuItem.getName(), menuItem.getPrice(), 1, menuItem.getImageUrl());
            cartItems.add(newItem);
        } else {
            existing.setQuantity(existing.getQuantity() + 1);
        }
        saveCart(context, cartItems);
    }

    public static void updateQuantity(Context context, int itemId, int quantity) {
        List<CartItem> cartItems = getCartItems(context);
        for (CartItem item : cartItems) {
            if (item.getItemId() == itemId) {
                item.setQuantity(Math.max(1, quantity));
                break;
            }
        }
        saveCart(context, cartItems);
    }

    public static void removeItem(Context context, int itemId) {
        List<CartItem> cartItems = getCartItems(context);
        for (int i = 0; i < cartItems.size(); i++) {
            if (cartItems.get(i).getItemId() == itemId) {
                cartItems.remove(i);
                break;
            }
        }
        saveCart(context, cartItems);
    }

    public static void clearCart(Context context) {
        getPreferences(context).edit().remove(KEY_CART_ITEMS).apply();
    }

    public static double calculateTotal(List<CartItem> cartItems) {
        double total = 0;
        for (CartItem item : cartItems) {
            total += item.getTotalPrice();
        }
        return total;
    }
}
