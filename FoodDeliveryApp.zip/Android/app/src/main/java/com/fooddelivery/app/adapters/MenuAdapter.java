package com.fooddelivery.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.fooddelivery.app.R;
import com.fooddelivery.app.models.MenuItem;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {

    public interface OnMenuItemListener {
        void onAddToCart(MenuItem menuItem);
    }

    private final List<MenuItem> menuItems = new ArrayList<>();
    private final OnMenuItemListener listener;
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

    public MenuAdapter(OnMenuItemListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        holder.bind(menuItems.get(position));
    }

    @Override
    public int getItemCount() {
        return menuItems.size();
    }

    public void updateMenuItems(List<MenuItem> newItems) {
        menuItems.clear();
        if (newItems != null) {
            menuItems.addAll(newItems);
        }
        notifyDataSetChanged();
    }

    class MenuViewHolder extends RecyclerView.ViewHolder {
        private final ImageView menuImage;
        private final TextView menuName;
        private final TextView menuDescription;
        private final TextView menuPrice;
        private final Button addButton;

        MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            menuImage = itemView.findViewById(R.id.menuImage);
            menuName = itemView.findViewById(R.id.menuName);
            menuDescription = itemView.findViewById(R.id.menuDescription);
            menuPrice = itemView.findViewById(R.id.menuPrice);
            addButton = itemView.findViewById(R.id.addToCartButton);
        }

        void bind(MenuItem item) {
            menuName.setText(item.getName());
            menuDescription.setText(item.getDescription());
            menuPrice.setText(currencyFormat.format(item.getPrice()));

            Glide.with(menuImage.getContext())
                    .load(item.getImageUrl())
                    .placeholder(R.drawable.ic_food_placeholder)
                    .error(R.drawable.ic_food_placeholder)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(menuImage);

            addButton.setEnabled(item.isAvailable());
            addButton.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onAddToCart(item);
                }
            });
        }
    }
}
