package com.fooddelivery.app.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.fooddelivery.app.R;
import com.fooddelivery.app.api.ApiClient;
import com.fooddelivery.app.models.Category;
import com.fooddelivery.app.models.MenuItem;
import com.google.android.material.progressindicator.LinearProgressIndicator;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AdminActivity extends AppCompatActivity {

    private TextView statsText;
    private LinearProgressIndicator progressIndicator;
    private SharedPreferences sharedPreferences;
    private Integer categoryCount;
    private Integer menuCount;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        sharedPreferences = getSharedPreferences("FoodDelivery", MODE_PRIVATE);
        statsText = findViewById(R.id.adminStatsText);
        progressIndicator = findViewById(R.id.adminProgress);
        Button refreshButton = findViewById(R.id.adminRefreshButton);
        Button openBackendButton = findViewById(R.id.adminBackendButton);

        refreshButton.setOnClickListener(v -> loadStats());
        openBackendButton.setOnClickListener(v -> {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(getString(R.string.admin_panel_url)));
            startActivity(browserIntent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadStats();
    }

    private void loadStats() {
        String token = sharedPreferences.getString("token", null);
        String role = sharedPreferences.getString("role", "");
        if (token == null) {
            Toast.makeText(this, R.string.admin_login_required, Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        if (!"admin".equalsIgnoreCase(role)) {
            Toast.makeText(this, R.string.admin_role_required, Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        progressIndicator.setVisibility(View.VISIBLE);
        statsText.setText(R.string.admin_loading);

        Call<List<Category>> categoriesCall = ApiClient.getApiService().getCategories();
        Call<List<MenuItem>> menuItemsCall = ApiClient.getApiService().getMenuItems();

        categoriesCall.enqueue(new Callback<List<Category>>() {
            @Override
            public void onResponse(Call<List<Category>> call, Response<List<Category>> response) {
                handleCategoriesResponse(response);
            }

            @Override
            public void onFailure(Call<List<Category>> call, Throwable t) {
                showError(t);
            }
        });

        menuItemsCall.enqueue(new Callback<List<MenuItem>>() {
            @Override
            public void onResponse(Call<List<MenuItem>> call, Response<List<MenuItem>> response) {
                handleMenuResponse(response);
            }

            @Override
            public void onFailure(Call<List<MenuItem>> call, Throwable t) {
                showError(t);
            }
        });
    }

    private void handleCategoriesResponse(Response<List<Category>> response) {
        List<Category> categories = response.body();
        categoryCount = categories != null ? categories.size() : 0;
        updateStatsText();
    }

    private void handleMenuResponse(Response<List<MenuItem>> response) {
        List<MenuItem> menuItems = response.body();
        menuCount = menuItems != null ? menuItems.size() : 0;
        updateStatsText();
    }

    private void updateStatsText() {
        if (categoryCount == null || menuCount == null) {
            return;
        }

        progressIndicator.setVisibility(View.GONE);
        statsText.setText(getString(R.string.admin_stats_format, categoryCount, menuCount));
    }

    private void showError(Throwable t) {
        progressIndicator.setVisibility(View.GONE);
        statsText.setText(R.string.admin_error_loading);
        Toast.makeText(this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
    }
}
