package com.fooddelivery.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fooddelivery.app.R;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class OrdersAdapter extends RecyclerView.Adapter<OrdersAdapter.OrderViewHolder> {

    private final List<Map<String, Object>> orders = new ArrayList<>();
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        holder.bind(orders.get(position));
    }

    @Override
    public int getItemCount() {
        return orders.size();
    }

    public void updateOrders(List<Map<String, Object>> newOrders) {
        orders.clear();
        if (newOrders != null) {
            orders.addAll(newOrders);
        }
        notifyDataSetChanged();
    }

    class OrderViewHolder extends RecyclerView.ViewHolder {
        private final TextView orderIdText;
        private final TextView orderStatusText;
        private final TextView orderDateText;
        private final TextView orderTotalText;

        OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            orderIdText = itemView.findViewById(R.id.orderIdText);
            orderStatusText = itemView.findViewById(R.id.orderStatusText);
            orderDateText = itemView.findViewById(R.id.orderDateText);
            orderTotalText = itemView.findViewById(R.id.orderTotalText);
        }

        void bind(Map<String, Object> order) {
            orderIdText.setText(itemView.getContext().getString(R.string.order_number_format, getInt(order, "id")));
            orderStatusText.setText(itemView.getContext().getString(R.string.order_status_format, getString(order, "status")));
            orderTotalText.setText(itemView.getContext().getString(R.string.order_total_format,
                    currencyFormat.format(getDouble(order, "totalAmount"))));

            long createdAt = getLong(order, "createdAt");
            if (createdAt > 0) {
                orderDateText.setText(dateFormat.format(new Date(createdAt)));
            } else {
                orderDateText.setText(R.string.order_date_unknown);
            }
        }

        private int getInt(Map<String, Object> map, String key) {
            Object value = map.get(key);
            if (value instanceof Number) {
                return ((Number) value).intValue();
            }
            try {
                return value != null ? Integer.parseInt(value.toString()) : 0;
            } catch (NumberFormatException e) {
                return 0;
            }
        }

        private double getDouble(Map<String, Object> map, String key) {
            Object value = map.get(key);
            if (value instanceof Number) {
                return ((Number) value).doubleValue();
            }
            try {
                return value != null ? Double.parseDouble(value.toString()) : 0d;
            } catch (NumberFormatException e) {
                return 0d;
            }
        }

        private long getLong(Map<String, Object> map, String key) {
            Object value = map.get(key);
            if (value instanceof Number) {
                return ((Number) value).longValue();
            }
            try {
                return value != null ? Long.parseLong(value.toString()) : 0L;
            } catch (NumberFormatException e) {
                return 0L;
            }
        }

        private String getString(Map<String, Object> map, String key) {
            Object value = map.get(key);
            return value != null ? value.toString() : "-";
        }
    }
}
