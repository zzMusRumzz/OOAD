package com.fooddelivery.app.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fooddelivery.app.R;
import com.fooddelivery.app.adapters.OrdersAdapter;
import com.fooddelivery.app.api.ApiClient;
import com.google.android.material.progressindicator.CircularProgressIndicator;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class OrdersActivity extends AppCompatActivity {

    private OrdersAdapter ordersAdapter;
    private View emptyStateView;
    private CircularProgressIndicator progressIndicator;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_orders);

        sharedPreferences = getSharedPreferences("FoodDelivery", MODE_PRIVATE);

        RecyclerView ordersRecyclerView = findViewById(R.id.ordersRecyclerView);
        emptyStateView = findViewById(R.id.ordersEmptyState);
        progressIndicator = findViewById(R.id.ordersProgress);

        ordersAdapter = new OrdersAdapter();
        ordersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        ordersRecyclerView.setAdapter(ordersAdapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadOrders();
    }

    private void loadOrders() {
        String token = sharedPreferences.getString("token", null);
        if (token == null) {
            Toast.makeText(this, R.string.orders_login_required, Toast.LENGTH_SHORT).show();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        progressIndicator.setVisibility(View.VISIBLE);
        emptyStateView.setVisibility(View.GONE);

    Call<List<Map<String, Object>>> call = ApiClient.getApiService().getOrders("Bearer " + token);
        call.enqueue(new Callback<List<Map<String, Object>>>() {
            @Override
            public void onResponse(Call<List<Map<String, Object>>> call, Response<List<Map<String, Object>>> response) {
                progressIndicator.setVisibility(View.GONE);
                if (response.isSuccessful() && response.body() != null && !response.body().isEmpty()) {
                    ordersAdapter.updateOrders(response.body());
                    emptyStateView.setVisibility(View.GONE);
                } else {
                    ordersAdapter.updateOrders(null);
                    emptyStateView.setVisibility(View.VISIBLE);
                }
            }

            @Override
            public void onFailure(Call<List<Map<String, Object>>> call, Throwable t) {
                progressIndicator.setVisibility(View.GONE);
                emptyStateView.setVisibility(View.VISIBLE);
                Toast.makeText(OrdersActivity.this, getString(R.string.error_network) + ": " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
