package com.fooddelivery.app.activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fooddelivery.app.R;
import com.fooddelivery.app.adapters.CartAdapter;
import com.fooddelivery.app.models.CartItem;
import com.fooddelivery.app.utils.CartManager;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class CartActivity extends AppCompatActivity implements CartAdapter.CartItemListener {

    private CartAdapter cartAdapter;
    private TextView totalPriceText;
    private View emptyStateView;
    private Button checkoutButton;
    private ProgressBar progressBar;
    private final NumberFormat currencyFormat = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        RecyclerView cartRecyclerView = findViewById(R.id.cartRecyclerView);
        totalPriceText = findViewById(R.id.cartTotalText);
        checkoutButton = findViewById(R.id.checkoutButton);
        Button clearCartButton = findViewById(R.id.clearCartButton);
        emptyStateView = findViewById(R.id.cartEmptyState);
        progressBar = findViewById(R.id.cartProgressBar);

        cartAdapter = new CartAdapter(this);
        cartRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        cartRecyclerView.setAdapter(cartAdapter);

        checkoutButton.setOnClickListener(v -> {
            // Navigate to checkout screen
            startActivity(new android.content.Intent(CartActivity.this, CheckoutActivity.class));
        });
        clearCartButton.setOnClickListener(v -> {
            CartManager.clearCart(CartActivity.this);
            refreshCart();
            Toast.makeText(CartActivity.this, R.string.cart_cleared, Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCart();
    }

    private void refreshCart() {
        progressBar.setVisibility(View.VISIBLE);
        List<CartItem> cartItems = CartManager.getCartItems(this);
        cartAdapter.updateItems(cartItems);
        double total = CartManager.calculateTotal(cartItems);
        totalPriceText.setText(getString(R.string.cart_total_format, currencyFormat.format(total)));
        emptyStateView.setVisibility(cartItems.isEmpty() ? View.VISIBLE : View.GONE);
        checkoutButton.setEnabled(!cartItems.isEmpty());
        progressBar.setVisibility(View.GONE);
    }

    @Override
    public void onQuantityChanged(CartItem item, int newQuantity) {
        CartManager.updateQuantity(this, item.getItemId(), newQuantity);
        refreshCart();
    }

    @Override
    public void onItemRemoved(CartItem item) {
        CartManager.removeItem(this, item.getItemId());
        refreshCart();
    }
}
