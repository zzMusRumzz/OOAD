package com.fooddelivery.app.api;

import com.fooddelivery.app.models.Category;
import com.fooddelivery.app.models.MenuItem;
import com.fooddelivery.app.models.CheckoutRequest;
import com.fooddelivery.app.models.CheckoutResponse;
import com.fooddelivery.app.models.Order;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.Headers;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {
    
    // Base URL will be: http://localhost:8080/api
    
    // Authentication endpoints
    @POST("auth/login")
    Call<Map<String, Object>> login(@Body Map<String, String> credentials);
    
    @POST("auth/register")
    Call<Map<String, Object>> register(@Body Map<String, String> user);
    
    // Categories endpoints (public)
    @GET("categories")
    Call<List<Category>> getCategories();
    
    @GET("categories/{id}")
    Call<Category> getCategory(@Path("id") int id);
    
    // Menu items endpoints (public)
    @GET("menu-items")
    Call<List<MenuItem>> getMenuItems();
    
    @GET("menu-items/{id}")
    Call<MenuItem> getMenuItem(@Path("id") int id);
    
    // Backend expects /api/menu-items?categoryId=ID not /menu-items/category/{id}
    @GET("menu-items")
    Call<List<MenuItem>> getMenuItemsByCategory(@Query("categoryId") long categoryId);
    
    // Admin endpoints (require JWT token)
    @POST("categories")
    Call<Category> createCategory(@Header("Authorization") String token, @Body Category category);
    
    @PUT("categories/{id}")
    Call<Category> updateCategory(@Header("Authorization") String token, @Path("id") int id, @Body Category category);
    
    @DELETE("categories/{id}")
    Call<Void> deleteCategory(@Header("Authorization") String token, @Path("id") int id);
    
    @POST("menu-items")
    Call<MenuItem> createMenuItem(@Header("Authorization") String token, @Body MenuItem menuItem);
    
    @PUT("menu-items/{id}")
    Call<MenuItem> updateMenuItem(@Header("Authorization") String token, @Path("id") int id, @Body MenuItem menuItem);
    
    @DELETE("menu-items/{id}")
    Call<Void> deleteMenuItem(@Header("Authorization") String token, @Path("id") int id);
    
    // Orders endpoints (require JWT token)
    @GET("orders")
    Call<List<Map<String, Object>>> getOrders(@Header("Authorization") String token);
    
    @POST("orders")
    Call<Map<String, Object>> createOrder(@Header("Authorization") String token, @Body Map<String, Object> order);
    
    @GET("orders/{id}")
    Call<Map<String, Object>> getOrder(@Header("Authorization") String token, @Path("id") int id);

    // Checkout (creates Order from cart items)
    @Headers({"Accept: application/json", "Content-Type: application/json; charset=UTF-8"})
    @POST("checkout")
    Call<CheckoutResponse> checkout(@Header("Authorization") String token, @Body CheckoutRequest request);

    // Payment actions for a given order
    @Headers({"Accept: application/json", "Content-Type: application/json; charset=UTF-8"})
    @POST("orders/{orderId}/payments/initiate")
    Call<Order> initiatePayment(@Header("Authorization") String token, @Path("orderId") long orderId);

    @Headers({"Accept: application/json", "Content-Type: application/json; charset=UTF-8"})
    @POST("orders/{orderId}/payments/confirm")
    Call<Order> confirmPayment(@Header("Authorization") String token, @Path("orderId") long orderId);

    @Headers({"Accept: application/json", "Content-Type: application/json; charset=UTF-8"})
    @POST("orders/{orderId}/cancel")
    Call<Order> cancelOrder(@Header("Authorization") String token, @Path("orderId") long orderId);

    // Address creation (extended for dynamic checkout)
    @Headers({"Accept: application/json", "Content-Type: application/json; charset=UTF-8"})
    @POST("addresses")
    Call<Map<String, Object>> createAddress(@Header("Authorization") String token, @Body Map<String, Object> addressBody);
}