package com.fooddelivery.app.models;

public class OrderItem {
    private long id;
    private long orderId;
    private long menuItemId;
    private int quantity;
    private double price;
    private String notes;

    public long getId() { return id; }
    public void setId(long id) { this.id = id; }
    public long getOrderId() { return orderId; }
    public void setOrderId(long orderId) { this.orderId = orderId; }
    public long getMenuItemId() { return menuItemId; }
    public void setMenuItemId(long menuItemId) { this.menuItemId = menuItemId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
