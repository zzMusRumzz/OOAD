package com.fooddelivery.app.activities;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.fooddelivery.app.R;
import com.fooddelivery.app.api.ApiClient;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {
    
    private EditText emailEditText, passwordEditText;
    private Button loginButton;
    private TextView registerLink;
    private SharedPreferences sharedPreferences;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        
        sharedPreferences = getSharedPreferences("FoodDelivery", MODE_PRIVATE);
        
        initViews();
        setupClickListeners();
    }
    
    private void initViews() {
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        loginButton = findViewById(R.id.loginButton);
        registerLink = findViewById(R.id.registerLink);
    }
    
    private void setupClickListeners() {
        loginButton.setOnClickListener(v -> performLogin());
        
        registerLink.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
            startActivity(intent);
        });
    }
    
    private void performLogin() {
        String identifier = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        
        if (identifier.isEmpty()) {
            emailEditText.setError("Vui lòng nhập email hoặc số điện thoại");
            return;
        }
        
        if (password.isEmpty()) {
            passwordEditText.setError("Vui lòng nhập mật khẩu");
            return;
        }
        
        loginButton.setEnabled(false);
        loginButton.setText("Đang đăng nhập...");
        
    Map<String, String> credentials = new HashMap<>();
    credentials.put("identifier", identifier);
        credentials.put("password", password);
        
        Call<Map<String, Object>> call = ApiClient.getApiService().login(credentials);
        call.enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(Call<Map<String, Object>> call, Response<Map<String, Object>> response) {
                loginButton.setEnabled(true);
                loginButton.setText("Đăng nhập");
                
                if (response.isSuccessful() && response.body() != null) {
                    Map<String, Object> result = response.body();
                    String token = (String) result.get("token");
                    
                    if (token != null) {
                        // Save login data
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("token", "Bearer " + token);
                        editor.putString("email", identifier);
                        
                        // Extract user info from response if available
                        Object userObject = result.get("user");
                        if (userObject instanceof Map<?, ?> userMap) {
                            Object fullName = userMap.get("fullName");
                            Object role = userMap.get("role");
                            Object userId = userMap.get("userId");

                            if (fullName instanceof String) {
                                editor.putString("fullName", (String) fullName);
                            }
                            if (role instanceof String) {
                                editor.putString("role", ((String) role).toLowerCase(Locale.ROOT));
                            }
                            if (userId instanceof Number) {
                                editor.putInt("userId", ((Number) userId).intValue());
                            }
                        }
                        
                        editor.apply();
                        
                        Toast.makeText(LoginActivity.this, "Đăng nhập thành công!", Toast.LENGTH_SHORT).show();
                        finish(); // Go back to MainActivity
                    } else {
                        Toast.makeText(LoginActivity.this, "Lỗi đăng nhập", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(LoginActivity.this, "Email hoặc mật khẩu không đúng", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Map<String, Object>> call, Throwable t) {
                loginButton.setEnabled(true);
                loginButton.setText("Đăng nhập");
                Toast.makeText(LoginActivity.this, "Lỗi kết nối: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}