package com.fooddelivery.app.models.enums;

public enum OrderStatus {
    PENDING,
    CONFIRMED,
    CANCELLED
}
