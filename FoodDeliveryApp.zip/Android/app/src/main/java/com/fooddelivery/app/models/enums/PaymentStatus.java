package com.fooddelivery.app.models.enums;

public enum PaymentStatus {
    PENDING,
    PAID
}
