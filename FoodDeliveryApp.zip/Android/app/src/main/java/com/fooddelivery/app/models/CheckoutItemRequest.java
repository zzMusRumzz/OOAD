package com.fooddelivery.app.models;

public class CheckoutItemRequest {
    private long menuItemId;
    private int quantity;
    private String notes;

    public CheckoutItemRequest(long menuItemId, int quantity, String notes) {
        this.menuItemId = menuItemId;
        this.quantity = quantity;
        this.notes = notes;
    }

    public long getMenuItemId() { return menuItemId; }
    public void setMenuItemId(long menuItemId) { this.menuItemId = menuItemId; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
