# Food Delivery Android App

Ứng dụng Android đặt đồ ăn online kết nối với backend API Spring Boot.

## Yêu cầu hệ thống
- Android Studio 2023.1.1 trở lên
- Android SDK API 33
- Java 8 trở lên
- Backend API chạy trên http://localhost:8080

## Cấu trúc dự án
```
app/
├── src/main/
│   ├── java/com/fooddelivery/app/
│   │   ├── activities/          # Các Activity chính
│   │   ├── adapters/           # RecyclerView Adapters
│   │   ├── api/                # API Service & Client
│   │   ├── models/             # Data Models
│   │   └── utils/              # Utility classes
│   ├── res/
│   │   ├── layout/             # Layout XML files
│   │   ├── drawable/           # Icons & drawables
│   │   ├── values/             # Strings, colors, styles
│   │   └── mipmap/             # App icons
│   └── AndroidManifest.xml
├── build.gradle                # Module dependencies
└── proguard-rules.pro
```

## Chức năng
- **Authentication**: Đăng nhập/đăng ký qua API
- **Browse Menu**: Xem danh mục và món ăn
- **Cart Management**: Quản lý giỏ hàng
- **Order Placement**: Đặt hàng
- **Admin Panel**: Quản lý danh mục và món ăn (cho admin)

## API Endpoints
Ứng dụng kết nối với các endpoint sau:
- `POST /api/auth/login` - Đăng nhập
- `POST /api/auth/register` - Đăng ký
- `GET /api/categories` - Lấy danh sách danh mục
- `GET /api/menu-items` - Lấy danh sách món ăn
- `POST /api/orders` - Tạo đơn hàng mới

## Cài đặt và chạy

### 1. Mở project trong Android Studio
```bash
# Clone hoặc tải project
cd FoodDeliveryApp
# Mở Android Studio và chọn thư mục này
```

### 2. Cấu hình kết nối API
Trong `ApiClient.java`, cập nhật BASE_URL:
- Emulator: `http://10.0.2.2:8080/api/`
- Device thật: `http://192.168.1.XXX:8080/api/` (thay XXX bằng IP của máy)

### 3. Chạy backend API
Đảm bảo Spring Boot backend đang chạy trên port 8080

### 4. Build và chạy
1. Sync project với Gradle
2. Chạy app trên emulator hoặc device thật

## Sử dụng

### Người dùng
1. Mở app và xem danh mục món ăn
2. Đăng nhập hoặc đăng ký tài khoản
3. Chọn món ăn và thêm vào giỏ hàng
4. Thanh toán và đặt hàng

### Admin
1. Đăng nhập với tài khoản admin
2. Vào phần "Quản lý"
3. Thêm/sửa/xóa danh mục và món ăn

## Công nghệ sử dụng
- **Language**: Java
- **Build Tool**: Gradle (Groovy)
- **Target SDK**: API 33
- **Architecture**: Activities + Fragments
- **Networking**: Retrofit2 + OkHttp3
- **Image Loading**: Glide
- **UI**: Material Design Components

## Ghi chú
- App cần quyền INTERNET để kết nối API
- Sử dụng SharedPreferences để lưu token đăng nhập
- Hỗ trợ cả chế độ sáng và tối